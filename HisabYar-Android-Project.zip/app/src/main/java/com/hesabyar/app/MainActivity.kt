package com.hesabyar.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var pendingImport: Boolean = false

    private val createBackup = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            val data = webView.evaluateJavascript("JSON.stringify(window.exportData())", null)
            // Use the JS bridge payload, stored before opening the document picker.
            val content = pendingBackupJson
            if (content != null) {
                contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                pendingBackupJson = null
                webView.evaluateJavascript("window.backupFinished(true)", null)
            }
        } else {
            pendingBackupJson = null
            webView.evaluateJavascript("window.backupFinished(false)", null)
        }
    }

    private var pendingBackupJson: String? = null

    private val openBackup = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val escaped = org.json.JSONObject.quote(text)
                webView.evaluateJavascript("window.importData($escaped)", null)
            } catch (_: Exception) {
                webView.evaluateJavascript("window.importFinished(false)", null)
            }
        }
        pendingImport = false
    }

    inner class AppBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackupJson = json
                createBackup.launch("HisabYar-backup.json")
            }
        }

        @JavascriptInterface
        fun chooseBackup() {
            runOnUiThread {
                pendingImport = true
                openBackup.launch(arrayOf("application/json", "text/*"))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
